import { useState, useEffect } from 'react';
import { authService, AuthState } from '@/lib/auth';
import { Contact } from '@/lib/database';
import Welcome from './Welcome';
import Auth from './Auth';
import Contacts from './Contacts';
import VerifyContact from './VerifyContact';
import Chat from './Chat';
import Settings from './Settings';

type Screen = 'welcome' | 'auth' | 'contacts' | 'verify' | 'chat' | 'settings';

export default function Index() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [authState, setAuthState] = useState<AuthState>({ isAuthenticated: false, user: null });
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  useEffect(() => {
    authService.init();
    const unsubscribe = authService.subscribe(setAuthState);
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (authState.isAuthenticated) {
      setCurrentScreen('contacts');
    } else {
      setCurrentScreen('welcome');
    }
  }, [authState.isAuthenticated]);

  const handleGetStarted = () => {
    setCurrentScreen('auth');
  };

  const handleAuthComplete = () => {
    setCurrentScreen('contacts');
  };

  const handleContactSelect = (contact: Contact) => {
    setSelectedContact(contact);
    setCurrentScreen('chat');
  };

  const handleVerifyContact = (contact: Contact) => {
    setSelectedContact(contact);
    setCurrentScreen('verify');
  };

  const handleContactVerified = (contact: Contact) => {
    setSelectedContact(contact);
    setCurrentScreen('chat');
  };

  const handleBackToContacts = () => {
    setSelectedContact(null);
    setCurrentScreen('contacts');
  };

  const handleOpenSettings = () => {
    setCurrentScreen('settings');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return <Welcome onGetStarted={handleGetStarted} />;
      
      case 'auth':
        return <Auth onComplete={handleAuthComplete} />;
      
      case 'contacts':
        return (
          <div className="relative">
            <Contacts
              onContactSelect={handleContactSelect}
              onVerifyContact={handleVerifyContact}
            />
            <button
              onClick={handleOpenSettings}
              className="absolute top-4 right-4 p-2 text-gray-600 hover:text-gray-900 text-2xl"
              title="Settings"
            >
              ⚙️
            </button>
          </div>
        );
      
      case 'verify':
        return selectedContact ? (
          <VerifyContact
            contact={selectedContact}
            onVerified={handleContactVerified}
            onBack={handleBackToContacts}
          />
        ) : null;
      
      case 'chat':
        return selectedContact ? (
          <Chat
            contact={selectedContact}
            onBack={handleBackToContacts}
          />
        ) : null;
      
      case 'settings':
        return <Settings onBack={handleBackToContacts} />;
      
      default:
        return <Welcome onGetStarted={handleGetStarted} />;
    }
  };

  return renderScreen();
}